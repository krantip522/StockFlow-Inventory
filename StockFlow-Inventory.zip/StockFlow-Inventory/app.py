from flask import Flask, request, jsonify
from decimal import Decimal
from sqlalchemy.exc import IntegrityError
from sqlalchemy import func, and_
from datetime import datetime, timedelta

app = Flask(__name__)

# Assuming db and models are imported
# from models import db, Product, Inventory, Warehouse, Supplier, ProductSupplier, Sale

# Hypothetical function for company ID (implement based on auth)
def get_current_company_id():
    return 1  # Placeholder; replace with real auth logic

# From Part 1: Fixed create_product endpoint
@app.route('/api/products', methods=['POST'])
def create_product():
    try:
        data = request.get_json()
        if not data:
            return jsonify({"error": "Invalid JSON"}), 400
        
        # Validate required fields
        required_fields = ['name', 'sku', 'warehouse_id', 'initial_quantity']
        for field in required_fields:
            if field not in data:
                return jsonify({"error": f"Missing required field: {field}"}), 400
        
        # Validate data types
        if not isinstance(data['initial_quantity'], int) or data['initial_quantity'] < 0:
            return jsonify({"error": "initial_quantity must be a non-negative integer"}), 400
        
        # Handle optional price (default to 0.00)
        price = Decimal(data.get('price', 0.00))
        if not isinstance(price, Decimal):
            try:
                price = Decimal(str(data.get('price', 0.00)))
            except:
                return jsonify({"error": "price must be a valid decimal"}), 400
        
        # Check SKU uniqueness and reuse existing product if found
        existing_product = Product.query.filter_by(sku=data['sku']).first()
        if existing_product:
            product = existing_product
        else:
            # Validate warehouse belongs to user's company (assumption)
            current_company_id = get_current_company_id()  # Hypothetical function
            warehouse = Warehouse.query.filter_by(id=data['warehouse_id'], company_id=current_company_id).first()
            if not warehouse:
                return jsonify({"error": "Invalid warehouse_id"}), 400
            
            product = Product(
                name=data['name'],
                sku=data['sku'],
                price=price,
                company_id=current_company_id  # Added for multi-tenancy
            )
            db.session.add(product)
        
        # Check if inventory already exists for this product-warehouse combo
        existing_inventory = Inventory.query.filter_by(product_id=product.id, warehouse_id=data['warehouse_id']).first()
        if existing_inventory:
            existing_inventory.quantity += data['initial_quantity']  # Update instead of create
        else:
            inventory = Inventory(
                product_id=product.id,
                warehouse_id=data['warehouse_id'],
                quantity=data['initial_quantity']
            )
            db.session.add(inventory)
        
        db.session.commit()  # Single commit for atomicity
        
        return jsonify({"message": "Product created or updated", "product_id": product.id}), 201
    
    except IntegrityError:
        db.session.rollback()
        return jsonify({"error": "Database integrity error (e.g., duplicate SKU)"}), 409
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": "Internal server error"}), 500

# From Part 3: get_low_stock_alerts endpoint
@app.route('/api/companies/<int:company_id>/alerts/low-stock', methods=['GET'])
def get_low_stock_alerts(company_id):
    try:
        # Security: Ensure user has access to this company (assumption)
        current_company_id = get_current_company_id()
        if current_company_id != company_id:
            return jsonify({"error": "Unauthorized"}), 403
        
        # Get current date and 30 days ago
        now = datetime.now()
        thirty_days_ago = now - timedelta(days=30)
        
        # Subquery for average daily sales in last 30 days
        avg_sales_subquery = db.session.query(
            Sale.product_id,
            func.avg(Sale.quantity_sold).label('avg_daily_sales')
        ).filter(
            Sale.sale_date >= thirty_days_ago.date()
        ).group_by(Sale.product_id).subquery()
        
        # Main query: Join tables and filter
        alerts_query = db.session.query(
            Inventory.product_id,
            Product.name.label('product_name'),
            Product.sku,
            Inventory.warehouse_id,
            Warehouse.name.label('warehouse_name'),
            Inventory.quantity.label('current_stock'),
            Product.threshold,
            Supplier.id.label('supplier_id'),
            Supplier.name.label('supplier_name'),
            Supplier.contact_email,
            avg_sales_subquery.c.avg_daily_sales
        ).join(Product, Inventory.product_id == Product.id)\
         .join(Warehouse, Inventory.warehouse_id == Warehouse.id)\
         .outerjoin(ProductSupplier, Product.id == ProductSupplier.product_id)\
         .outerjoin(Supplier, ProductSupplier.supplier_id == Supplier.id)\
         .outerjoin(avg_sales_subquery, Product.id == avg_sales_subquery.c.product_id)\
         .filter(
             and_(
                 Product.company_id == company_id,
                 Inventory.quantity < Product.threshold,  # Below threshold
                 avg_sales_subquery.c.avg_daily_sales.isnot(None)  # Has recent sales
             )
         ).all()
        
        alerts = []
        for row in alerts_query:
            # Calculate days until stockout
            avg_sales = row.avg_daily_sales or 0
            days_until_stockout = int(row.current_stock / avg_sales) if avg_sales > 0 else 999
            
            alerts.append({
                "product_id": row.product_id,
                "product_name": row.product_name,
                "sku": row.sku,
                "warehouse_id": row.warehouse_id,
                "warehouse_name": row.warehouse_name,
                "current_stock": row.current_stock,
                "threshold": row.threshold,
                "days_until_stockout": days_until_stockout,
                "supplier": {
                    "id": row.supplier_id or None,
                    "name": row.supplier_name or "",
                    "contact_email": row.contact_email or ""
                }
            })
        
        return jsonify({
            "alerts": alerts,
            "total_alerts": len(alerts)
        }), 200
    
    except Exception as e:
        return jsonify({"error": "Internal server error"}), 500

if __name__ == '__main__':
    app.run(debug=True)